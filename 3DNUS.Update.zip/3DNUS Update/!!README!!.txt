Welcome to 3DNUS;

This is a FREE to use Application, It is fully working.
The Current version you have is: Version 2.5.4.
3DNUS Allows you (The User) to download "3DS Firmwares/Titles" with ease.
If you wish to use them on a real 3DS (New Or OLD), Then please read the Tutorial below.

Note: .NET 4.1 & Powerpack are required! 
As well as some .NET Redist Files (In the Folder Called "redist")


***=================Installing Cia's======================***	
In order to install .cia's/.3ds/.3dsx/etc perform the Following;
Make a Folder Called "Package_Title" then place any .cia's/.3ds/.3dsx's.
To install them, go to "Virtual NAND Mode/Install/Title or Firmware,"
Then, a "Open File Dialog" will Open, Select the File in the "Package_Title" folder you
created. Then the Installer will Open. Due to some Minor Bugs, you'll need to Remove the File
Extension for Now! Ex: "00000.cia" needs to be "00000" instead. This makes sure the Package is Properly 
Installed. If there is an Error Saying "Title Already Installed!!," Then you'll need to Remove the VNM Folder;
(This is a Rare Error!), if it still fails, the Package may be Invalid or is Not Signed! Also, the "Package" File is 
Removed after the Install, which would be ".cia/3ds/3dsx" files. Make sure you Back-Up your Files Elsewhere;
(This May be Fixed Later).


***=================Changelog======================***
"PR" Stands for Pre/Preview Release, while "FR" Stands for Full Release or Final. 
"BR" or "AR" Stands for Beta/Alpha Release.

		  **2.5.4.5;v29366 (FR)**
 	-Fixed some Bugs
	-Fixed some Bugs in VNM
	-Working on DevKit 

		  **2.5.4.5 (PR)**
 	-Fixed some Bugs
	-Added Settings Config's
	
		  **2.5.3 (FR)**
	-Fixed some Minor Bugs
	-Added some more Features to VNM
	-Fixed an Error when Using the .CIA installer for VNM

		   **2.5.3(PR)**
	-Added VNM .cia/.3ds/.3dsx Installer
	-Fixed VNM Not Loading Properly
	-Added VNM_SYS (To Properly Load SYS_)
	-Added VNM_Package Recognition Code
	-Fixed Some Minor Bugs
	-Added SYS_UPD (For VNM, to Check for Updates)
	-Added VNM_CORE (For Core 3DS VNM Emulation)
	-Fixed Some Minor Bugs with VNM
	-Fixed VNM Failing to Install System Cia's (Some)

		     **2.5.2(BR)**
	-Fixed Some Minor Bugs
	-Added VNM	
	-Fixed Some Bugs when Downloading FW's
	-Added Some Core-3DS Emu 

		     **2.5.1(BR)**
		   (No Changelog)

		     **2.5.0(AR)**
		   (No Changelog)

		     **2.4.3(BR)**
		   (No Changelog)

		     **2.4.2(FR)**
		   (No Changelog)


***=================Tutorial======================***


To install ".cia" files Packed in 3DSNUS, perform the following:

1. Download (Using 3DNUS) a Firmware or Title; Ex: 4.0.0-3 (In FIRM Version Textbox);
In the Region Type "Your Region: USA/EUR/TWN/JPN/CHN", then click download; Also Select New 3DS or Old 3DS;
If the App freezes at any point, try a different version#.
Also make sure to tick "Pack as .CIA"

2. Now on your 3DS (With all .CIA's on SDCard), install the .CIA's like any other, 
but remember to do it on a EmuNAND (And Make A backup!).
Note: Downgrading is DANGEROUS!! Upgrading is a little less dangerous;
But remember, Im not responsable for any damage done to you 3DS, but i may help
you to fix your issue. Downgrading from 10.x ----> 4.x is possible but DANGEROUS!!;
6.x or 7.x ----> 4.x or 3.x is a little safer.

3.Reboot your System (While Crossing You Fingers); If it boot's your good to go!


4. Check your System Version!






3DNUS Project by ground; Maintained and Now Worked on by: Dr.Hacknik (luke dixon)

Thread: http://gbatemp.net/threads/3dnus-mod-by-dr-hacknik.392360/#post-5567457

Thanks for your Support!!  :)
