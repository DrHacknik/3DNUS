[Profile: _Default]
[3DNUS Profile Manager]
[Running On v2.5.5b of 3DNUS]

{
My.Settings.Load();
Me.Profile = My.Settings.Profile_Current
Me.Refresh();

}

[End Of: Profile _Default]