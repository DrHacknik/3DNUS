﻿namespace System.Web
{
    internal class Mail
    {
    }
}